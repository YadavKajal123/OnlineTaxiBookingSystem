USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Delete_Procedure_Customer]    Script Date: 10/25/2018 5:47:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Delete_Procedure_Customer]
@CustomerId varchar(10)
AS
BEGIN  
DELETE FROM [Group-2(OTBS)].[Customer] WHERE [CustomerID] = @CustomerId 
END 

GO


