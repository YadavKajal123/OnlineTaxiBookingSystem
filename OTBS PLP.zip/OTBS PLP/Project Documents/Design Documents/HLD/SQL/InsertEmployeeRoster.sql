USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Procedure_EmployeeRoster]    Script Date: 10/25/2018 5:44:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Procedure_EmployeeRoster]


@EmployeeID int,
@FromDate date,
@ToDate date,
@InTime time,
@OutTime time,
@Total_Trips int
AS
Insert into [Group-2(OTBS)].[EmployeeRoster]([EmployeeID],[FromDate],[ToDate],[InTime],[OutTime],[Total_Trips])
 Values(@EmployeeID,@FromDate,@ToDate,@InTime,@OutTime,@Total_Trips);

GO


