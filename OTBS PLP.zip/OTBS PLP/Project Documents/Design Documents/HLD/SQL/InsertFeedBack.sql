USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Feedback]    Script Date: 10/25/2018 5:49:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Feedback]
@Name varchar,
@CustomerExperience int,
@CustomerRide int,
@CustomerComfort int,
@OverallExperience int

AS

Insert into [Group-2(OTBS)].[Feedback](Name,CustomerExperience,CustomerRide,CustomerComfort,OverallExperience)
 Values(@Name,@CustomerExperience,@CustomerRide,@CustomerComfort,@OverallExperience)
GO


