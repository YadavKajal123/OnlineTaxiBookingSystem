USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Procedure_Users]    Script Date: 10/25/2018 5:47:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Procedure_Users]
@LoginID int,
@Password varchar(20),
@EmployeeID int,
@CustomerID int,
@Role varchar(10)
AS
Insert into [Group-2(OTBS)].[Users]([Password],[EmployeeID],[CustomerID],[Role])
 Values(@Password,@EmployeeID,@CustomerID,@Role)
GO


