USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Select_Procedure_Admin]    Script Date: 10/25/2018 5:49:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [Group-2(OTBS)].[OTBS_Select_Procedure_Admin]
	@EmailId varchar(40),
	@Password varchar(20)
AS
	select EmailId,[Password] from  [Group-2(OTBS)].[Admin] where EmailId=@EmailId and [Password]=@Password
RETURN 0
GO


