USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_Booking]    Script Date: 10/25/2018 5:50:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_Booking]


@BookingID varchar(10),
@CustomerID varchar(10),
@TaxiID varchar(10),
@BookingDate date,
@TripDate date,
@StartTime time(7),
@EndTime time(7),
@SourceAddress varchar(50),
@DestinationAddress varchar(50),
@Distance int,
@Status varchar(30),
@CarType varchar(30)

AS

    Update Booking set	 
	 BookingDate = @BookingDate,
	 TripDate = @TripDate,
	 StartTime = @StartTime,
	 EndTime = @EndTime,
	 SourceAddress = @SourceAddress,
	 DestinationAddress = @DestinationAddress,
	 Distance=@Distance,
	 [Status]=@Status,
	 CarType=@CarType
	 Where BookingID = @BookingID
GO


