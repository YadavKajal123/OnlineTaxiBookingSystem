USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_Customer]    Script Date: 10/25/2018 5:50:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_Customer]


@CustomerID varchar(10),
@CustomerName char(30),
@PhoneNumber varchar(10),
@EmailID varchar(40),
@Address varchar(50),
@Password varchar(50)

AS

    Update OTBS_Update_Procedure_Customer set	 
	 CustomerName = @CustomerName,
	 PhoneNumber = @PhoneNumber,
	 EmailID = @EmailID,
	 Address = @Address,
	 Password=@Password
	 Where CustomerID = @CustomerID
GO


