USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_Employee]    Script Date: 10/25/2018 5:51:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_Employee]

-- Add the parameters for the stored procedure here
@EmployeeID varchar(10),
@EmployeeName varchar(30),
@Designation varchar(25),
@PhoneNumber varchar(10),
@EmailID varchar(30),
@Address varchar(50),
@DrivingLicenseNumber varchar(25)

AS
    Update OTBS_Update_Procedure_Employee set	 
	 EmployeeName = @EmployeeName,
	 Designation = @Designation,
	 PhoneNumber = @PhoneNumber,
	 EmailID = @EmailID,
	 Address = @Address,
	 DrivingLicenseNumber = @DrivingLicenseNumber
	 Where EmployeeID = @EmployeeID


GO


