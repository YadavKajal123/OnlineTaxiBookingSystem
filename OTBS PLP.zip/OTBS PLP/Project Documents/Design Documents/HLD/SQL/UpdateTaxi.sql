USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_Taxi]    Script Date: 10/25/2018 5:51:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_Taxi]

-- Add the parameters for the stored procedure here
@TaxiID varchar(10),
@TaxiModel varchar(20),
@TaxiColor char(10),
@TaxiRegistrationNumber varchar(15),
@TaxiType char(10)

AS
    Update OTBS_Update_Procedure_Taxi set	 
	 TaxiID = @TaxiID,
	 TaxiModel = @TaxiModel,
	 TaxiColor = @TaxiColor,
	 TaxiRegistrationNumber = @TaxiRegistrationNumber,
	 TaxiType = @TaxiType
	 Where TaxiID = @TaxiID
GO


