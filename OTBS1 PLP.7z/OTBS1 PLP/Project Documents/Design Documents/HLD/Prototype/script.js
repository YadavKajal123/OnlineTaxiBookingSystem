function redirectpage()
{
	if(document.getElementById('txtUserID').value=="714709" && document.getElementById('txtPassword').value=="karthik")
	{
		window.location.href = "options.html";
	}
	else
	{
	document.getElementById('loginError').innerHTML="Invalid user Credentials";
	document.getElementById('txtUserID').value="";
	document.getElementById('txtPassword').value="";
	}
}
function clearText()
{
	document.getElementById('txtUserID').value="";
	document.getElementById('txtPassword').value="";
	document.getElementById('loginError').innerHTML="";
		
}

function modify()
{
	if(document.getElementById('txtLastName').value=="")
	{
		document.getElementById('modifySuccess').innerHTML="";
		document.getElementById('lastNameErr').innerHTML="(Required)";
	}
	else
	{
		document.getElementById('modifySuccess').innerHTML="Employee details modified successfully";
		document.getElementById('lastNameErr').innerHTML="";
	}
}

function addEmployee()
{
	
	if(/^\d{3}-\d{4}-\d{4}$/.test(document.getElementById('txtContactNumber').value))
	{
		/*document.getElementById('addSuccess').innerHTML="Employee with id 710001 added successfully";
		document.getElementById('contactNumber').innerHTML="";*/
			window.location.href = "ViewEmployee.html";
		
	} 
	else
	{
		document.getElementById('addSuccess').innerHTML="";
		document.getElementById('contactNumber').innerHTML="Invalid contact number";
		
	}
}
function upload()
{
	if(document.getElementById('fileUpload').value.length==0)
	{
		document.getElementById('uploadSuccess').innerHTML="";
		document.getElementById('uploadError').innerHTML="Please select a file to upload";
	}
	else if(document.getElementById('fileUpload').value.indexOf(".csv")==-1)
	{
		document.getElementById('uploadSuccess').innerHTML="";
		document.getElementById('uploadError').innerHTML="Invalid CSV File";
	}
	else
	{
		document.getElementById('uploadSuccess').innerHTML="1000 out of 1000 records inserted in 2 seconds";
		document.getElementById('uploadError').innerHTML="";
	}
		
	
}

function searchShowDiv()
{
   document.getElementById("searchResults").style.display="block";
}

function searchHideDiv()
{
	document.getElementById("searchResults").style.display="none";
}

function gotoModify()
{
	window.location.href = "ModifyEmployee.html";
}

function gotoSearch()
{
window.location.href = "SearchEmployee.html";
}