USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Delete_Procedure_EmployeeRoster]    Script Date: 10/25/2018 5:48:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Delete_Procedure_EmployeeRoster]
@EmployeeID varchar(10)
AS
BEGIN  
DELETE FROM [Group-2(OTBS)].[EmployeeRoster] WHERE [EmployeeID] = @EmployeeID
END 

GO


