USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Procedure_Booking]    Script Date: 10/25/2018 5:43:22 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Procedure_Booking]
@CustomerID int,
@TaxiID int,
@BookingDAte Date,
@TripDAte Date,
@StartTime time,
@EndTime time,
@SourceAddress varchar(50),
@DestinationAddress varchar(50),
@Distance int,
@Status varchar(30),
@CarType varchar(30)
AS
Insert into [Group-2(OTBS)].[Booking](CustomerID,TaxiID,BookingDate,TripDate,StartTime,EndTime,SourceAddress,DestinationAddress,Distance,[Status],CarType)
 Values(@CustomerID,@TaxiID,@BookingDAte,@TripDAte,@StartTime,@EndTime,@SourceAddress,@DestinationAddress,@Distance,@Status,@CarType)
GO

