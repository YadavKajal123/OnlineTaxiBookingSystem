USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Procedure_Customer]    Script Date: 10/25/2018 5:44:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Procedure_Customer]
@CustomerName char(10),
@PhoneNumber varchar(10),
@EmailId varchar(40),
@Address varchar(50),
@Password varchar(50)
AS
Insert into [Group-2(OTBS)].[Customer](CustomerName,PhoneNumber,EmailID,Address,Password)
 Values(@CustomerName,@PhoneNumber,@EmailId,@Address,@Password)
GO


