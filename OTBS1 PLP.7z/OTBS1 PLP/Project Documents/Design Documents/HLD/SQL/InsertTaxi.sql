USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Insert_Procedure_Taxi]    Script Date: 10/25/2018 5:45:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Insert_Procedure_Taxi]
@TaxiModel varchar(20),
@TaxiColor char(10),
@TaxiRegistrationNumber varchar(15),
@TaxiType char(10)
AS
Insert into [Group-2(OTBS)].[Taxi]([TaxiModel],[TaxiColor],[TaxiRegistrationNumber],[TaxiType])
 Values(@TaxiModel,@TaxiColor,@TaxiRegistrationNumber,@TaxiType)
GO


