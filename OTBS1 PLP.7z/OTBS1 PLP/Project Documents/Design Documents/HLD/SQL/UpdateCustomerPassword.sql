USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_CustomerPassword]    Script Date: 10/25/2018 5:50:51 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_CustomerPassword]
@PhoneNumber varchar(10),
@Password varchar(50)

AS

    Update [Group-2(OTBS)].Customer set
	 Password=@Password
	 Where PhoneNumber=@PhoneNumber

	 
GO


