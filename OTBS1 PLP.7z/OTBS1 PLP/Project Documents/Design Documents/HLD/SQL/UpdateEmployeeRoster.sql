USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_EmployeeRoster]    Script Date: 10/25/2018 5:51:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_EmployeeRoster]
@EmployeeID varchar(10),
@FromDate date,
@ToDate date,
@InTime time(7),
@OutTime time(7)

AS

    Update   [Group-2(OTBS)].[EmployeeRoster]  set	 
	 FromDate = @FromDate,
	 ToDate = @ToDate,
	 InTime = @InTime,
	 OutTime = @OutTime
	 Where EmployeeID = @EmployeeID


GO


