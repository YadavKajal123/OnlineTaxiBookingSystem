USE [8Aug_MIPL]
GO

/****** Object:  StoredProcedure [Group-2(OTBS)].[OTBS_Update_Procedure_Users]    Script Date: 10/25/2018 5:52:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Group-2(OTBS)].[OTBS_Update_Procedure_Users]

-- Add the parameters for the stored procedure here
@LoginID varchar(10),
@Password varchar(20),
@Role varchar(15)

AS

    Update OTBS_Update_Procedure_Users set	 
	 LoginId = @LoginID,
	 Password = @Password,
	 Role = @Role
	 Where LoginID = @LoginID
	 
GO


